sub init()
    m.top.panelSize = "narrow"
    m.top.hasNextPanel = true
    m.top.leftOnly = true
    m.top.createNextPanelOnItemFocus = false
    m.top.selectButtonMovesPanelForward = true
    m.top.optionsAvailable = false
    m.top.overhangTitle = ""
    m.top.list = m.top.findNode("menuLabelList")
    m.name = "List"
end sub