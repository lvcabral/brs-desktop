sub init()
    m.top.functionName = "getContent"
    m.name = "ContentReader"
    m.inSimulator = InSimulator()
end sub

sub getContent()
    content = createObject("roSGNode", "ContentNode")

    appManager = createObject("roAppManager")
    if inSimulator()
        ' "true" requests the extended app data, which adds the "icon" field (a file:// URI to a
        ' locally cached per-app PNG in the simulator). The plain call only returns id/title/version.
        apps = appManager.getAppList(true)
    else
        apps = appManager.getAppList()
    end if
    if apps <> invalid
        for each app in apps
            title = app.title
            if app.id = "dev" then title += " (dev)"

            version = app.version
            if version = invalid then version = "n/a"
            print app
            itemContent = content.createChild("ContentNode")
            itemContent.id = app.id
            itemContent.title = title
            itemContent.shortDescriptionLine1 = "Version " + version
            itemContent.description = "Version " + version + Chr(10) + Chr(10) + "Package Path: " + Chr(10) + app.path
            itemContent.HDPosterUrl = getAppIcon(app)
        end for
    end if

    addShortcut(content, "add-apps", "Add Apps", "pkg:/images/add-apps.png", "Add a BrightScript app package to the simulator")
    addShortcut(content, "turn-off", "Turn Off", "pkg:/images/turn-off.png", "Turn off the simulator")

    m.top.content = content
end sub

sub addShortcut(content as object, id as string, title as string, icon as string, description as string)
    item = content.createChild("ContentNode")
    item.id = id
    item.title = title
    item.shortDescriptionLine1 = title
    item.description = description
    item.HDPosterUrl = icon
end sub

function getAppIcon(app as object) as string
    icon = app.icon
    if icon = invalid or icon = ""
        return "pkg:/images/icon-hd.png"
    end if

    ' PosterGrid's HDPosterUrl loads pkg:/ and http(s):// natively (roTextureManager), but it
    ' doesn't understand file:// URIs - the simulator's icon field uses that scheme, so it must
    ' be cached to tmp:/ first via roUrlTransfer, the same fallback brs-home's CacheFile() does.
    if not icon.startsWith("file:")
        return icon
    end if

    cached = "tmp:/icon-" + app.id + ".png"
    fs = createObject("roFileSystem")
    if not fs.exists(cached)
        http = createObject("roUrlTransfer")
        http.setUrl(icon)
        if http.getToFile(cached) <> 200
            return "pkg:/images/icon-hd.png"
        end if
    end if
    return cached
end function

function InSimulator() as boolean
    di = CreateObject("roDeviceInfo")
    return di.hasFeature("simulation_engine")
end function
