sub init()
    m.top.panelSize = "wide"
    m.top.focusable = true
    m.top.hasNextPanel = true
    m.top.createNextPanelOnItemFocus = false
    m.top.selectButtonMovesPanelForward = false
    m.top.optionsAvailable = true

    m.posterGrid = m.top.findNode("contentGrid")
    m.labelList = m.top.findNode("contentList")
    m.top.grid = m.posterGrid

    m.posterGrid.observeField("itemFocused", "updateLabels")
    m.labelList.observeField("itemFocused", "updateLabels")
    m.posterGrid.observeField("itemFocused", "updateFocusedItem")
    m.labelList.observeField("itemFocused", "updateFocusedItem")
    m.top.observeField("focusedChild", "updateLabels")
    m.top.observeField("focusedChild", "updateFocusedItem")

    m.posterGrid.observeField("itemSelected", "onAppSelected")
    m.labelList.observeField("itemSelected", "onSettingSelected")

    m.name = "Grid"
end sub

sub onAppSelected()
    content = m.posterGrid.content
    if content = invalid then return
    item = content.getChild(m.posterGrid.itemSelected)
    if item = invalid then return
    launchApp(item.id)
end sub

sub onSettingSelected()
    content = m.labelList.content
    if content = invalid then return
    item = content.getChild(m.labelList.itemSelected)
    if item = invalid then return
    launchApp(item.id)
end sub

sub launchApp(id as string)
    ndk = createObject("roNDK") ' bs:disable-line
    if ndk = invalid then return
    ndk.start("SDKLauncher", ["ChannelId=" + id])

    ' "Add Apps"/"Turn Off" are simulator shortcuts handled by SDKLauncher without leaving this
    ' screen; launching a real app, like on the actual Roku Home Screen, exits this channel.
    if id <> "add-apps" and id <> "turn-off" and left(id, 8) <> "settings"
        scene = m.top.getScene()
        scene.exitApp = true
    end if
end sub

sub removeApp(id as string)
    ndk = createObject("roNDK") ' bs:disable-line
    if ndk = invalid then return
    ndk.start("SDKLauncher", ["ChannelId=" + id, "remove=1"])

    content = m.posterGrid.content
    if content = invalid then return

    index = m.posterGrid.itemFocused
    item = content.getChild(index)
    if item = invalid or item.id <> id then return

    content.removeChild(item)
    m.posterGrid.content = content

    ' Keep focus on the same index, so whichever app was next slides into this position.
    count = content.getChildCount()
    if count > 0
        nextIndex = index
        if nextIndex > count - 1 then nextIndex = count - 1
        m.posterGrid.jumpToItem = nextIndex
    end if
    updateLabels()
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    ' The "add-apps"/"turn-off" shortcuts aren't real apps - no options dialog for those.
    if press and key = "options" and not m.top.listMode
        showAppOptions()
        return true
    end if
    return false
end function

sub showAppOptions()
    content = m.posterGrid.content
    if content = invalid then return
    item = content.getChild(m.posterGrid.itemFocused)
    if item = invalid or item.id = "add-apps" or item.id = "turn-off" then return

    m.appOptionsId = item.id
    ' Set before the dialog steals key focus, so HomeScene.slidePanels() can tell the resulting
    ' focusedChild change apart from a real panel-set navigation and ignore it.
    m.top.dialogShowing = true

    dialog = createObject("roSGNode", "StandardMessageDialog")
    dialog.title = item.title
    dialog.message = [item.shortDescriptionLine1]
    dialog.buttons = ["Open App", "Remove App", "Close"]
    dialog.observeFieldScoped("buttonSelected", "onAppOptionSelected")
    dialog.observeFieldScoped("wasClosed", "onAppOptionsDialogClosed")
    m.appOptionsDialog = dialog

    scene = m.top.getScene()
    scene.dialog = dialog
end sub

sub onAppOptionSelected()
    buttonIndex = m.appOptionsDialog.buttonSelected
    id = m.appOptionsId

    if buttonIndex = 0
        launchApp(id)
    else if buttonIndex = 1
        removeApp(id)
    end if

    m.appOptionsDialog.close = true
end sub

' Fires no matter how the dialog went away (a button, Back, Options again, another dialog).
sub onAppOptionsDialogClosed()
    ' Restore focus while HomeScene is still ignoring focusedChild (dialogShowing still true),
    ' then clear the flag and refresh the labels ourselves - re-computing them via the observer
    ' would still be suppressed by the still-true flag at the moment focus actually moves.
    m.top.setFocus(true)
    m.top.dialogShowing = false
    updateLabels()
    updateFocusedItem()
end sub

sub setListMode()
    if m.top.listMode
        m.top.grid = m.labelList
        m.labelList.visible = true
        m.posterGrid.visible = false
    else
        m.top.grid = m.posterGrid
        m.posterGrid.visible = true
        m.labelList.visible = false
    end if
end sub

sub setGridContent()
    m.top.grid.content = m.top.gridContent
    updateLabels()
    updateFocusedItem()
end sub

' Surfaces whichever item is currently focused in the active grid/list, so HomeScene can reflect it
' in the sliding description panel (InfoPanel) - only meaningful once focus has actually moved
' off the left menu and into this panel.
sub updateFocusedItem()
    if m.top.dialogShowing then return
    if m.top.focusedChild = invalid then return

    content = m.top.grid.content
    if content = invalid then return

    m.top.focusedItem = content.getChild(m.top.grid.itemFocused)
end sub

sub updateLabels()
    ' Ignore the focus change caused by the options dialog stealing/returning focus - leave
    ' whatever labels were already showing alone.
    if m.top.dialogShowing then return

    ' Settings is a short, self-explanatory list - it doesn't need a header at all.
    if m.top.listMode
        m.top.leftLabel.text = ""
        m.top.rightLabel.text = ""
        return
    end if

    ' While this panel hasn't actually received focus yet (still just previewed from the
    ' left menu), show the scene-supplied heading instead of a specific grid item.
    if m.top.focusedChild = invalid
        m.top.leftLabel.text = m.top.previewTitle
        m.top.rightLabel.text = ""
        return
    end if

    content = m.top.grid.content
    count = 0
    if content <> invalid then count = content.getChildCount()

    focusedIndex = m.top.grid.itemFocused
    title = ""
    if count > 0
        item = content.getChild(focusedIndex)
        if item <> invalid then title = item.title
    end if

    m.top.leftLabel.text = title
    m.top.rightLabel.text = (focusedIndex + 1).toStr() + " of " + count.toStr() + " Items"
end sub