sub init()
    m.top.backgroundURI = "pkg:/images/background-hd.png"

    m.top.Overhang.showOptions = true
    m.top.Overhang.logoUri = "pkg:/images/simulator-overhang-logo.png"

    setDialogTheme()

    m.appsContent = invalid

    m.readContentTask = createObject("roSGNode", "ContentReader")
    m.readContentTask.observeField("content", "setAppsContent")
    m.readContentTask.control = "RUN"

    m.listPanel = m.top.panelSet.createChild("ListPanelExample")
    m.listPanel.list.content = getMenuContent()
    m.listPanel.list.observeField("itemFocused", "showGridPanel")

    m.gridPanel = m.top.panelSet.createChild("GridPanelExample")
    m.gridPanel.observeField("focusedChild", "slidePanels")
    m.gridPanel.observeField("focusedItem", "updateInfoPanel")

    showGridPanel()
    m.listPanel.setFocus(true)
end sub

' Applied to the Scene so it's inherited by every StandardDialog-derived node (e.g. the app options
' dialog in gridpanel.brs) without each one needing its own palette field set.
sub setDialogTheme()
    palette = createObject("roSGNode", "RSGPalette")
    palette.colors = {
        DialogBackgroundColor: "0xFFFFFFFF"
        DialogTextColor: "0x1A1A1AFF"
        DialogSecondaryTextColor: "0x666666FF"
        DialogSecondaryItemColor: "0xCCCCCCFF"
        DialogFocusColor: "0x662D91FF"
        DialogFocusItemColor: "0xFFFFFFFF"
    }
    m.top.palette = palette
end sub

function getMenuContent() as object
    content = createObject("roSGNode", "ContentNode")

    home = content.createChild("ContentNode")
    home.id = "home"
    home.title = "Home"
    home.description = "All apps available on this device"

    settings = content.createChild("ContentNode")
    settings.id = "settings"
    settings.title = "Settings"
    settings.description = "Device and channel settings"

    return content
end function

function getSettingsContent() as object
    content = createObject("roSGNode", "ContentNode")
    labels = ["Display", "Audio", "Captioning", "System"]
    for each label in labels
        item = content.createChild("ContentNode")
        item.id = "settings_" + LCase(label)
        item.title = label
        item.description = label + " settings"
        ' "image" isn't a standard ContentNode metadata field, so plain dot-assignment fails with
        ' "Tried to set nonexistent field" - AddFields() both declares and sets it.
        item.addFields({ image: "pkg:/images/" + LCase(label) + ".webp" })
    end for
    return content
end function

sub setAppsContent()
    m.appsContent = m.readContentTask.content
    showGridPanel()
end sub

sub showGridPanel()
    menuItem = m.listPanel.list.content.getChild(m.listPanel.list.itemFocused)
    if menuItem = invalid then return

    m.panel = createObject("roSGNode", "PanelExample")
    m.panel.description = menuItem.description

    if menuItem.id = "home"
        m.gridPanel.previewTitle = "Your Apps"
        m.gridPanel.listMode = false
        m.gridPanel.gridContent = m.appsContent
    else
        m.gridPanel.listMode = true
        m.gridPanel.gridContent = getSettingsContent()
    end if
end sub

' Reflects whichever app/setting item currently has focus in the grid/list panel - takes over from
' the static menu-level description set in showGridPanel() once the user actually moves into it.
sub updateInfoPanel()
    item = m.gridPanel.focusedItem
    if item = invalid or m.panel = invalid then return

    m.panel.description = item.description
    m.panel.image = item.image
end sub

sub slidePanels()
    ' The options dialog stealing/returning focus also changes focusedChild - ignore it, it has
    ' nothing to do with sliding between panels.
    if m.gridPanel.dialogShowing then return

    if not m.top.panelSet.isGoingBack
        m.top.panelSet.appendChild(m.panel)
        m.gridPanel.setFocus(true)
        m.gridPanel.hasNextPanel = false
    else
        m.listPanel.setFocus(true)
        m.gridPanel.hasNextPanel = true
    end if
end sub
