sub init()
    m.top.panelSize = "narrow"
    m.top.focusable = false
    m.top.hasNextPanel = false
    m.top.suppressLeftArrow = true
    m.infoLabel = m.top.findNode("infoLabel")
    m.infoPoster = m.top.findNode("infoPoster")
end sub

' When an image is provided (e.g. a Settings item), show it as a poster instead of the text label.
sub updateDisplay()
    hasImage = m.top.image <> invalid and m.top.image <> ""
    m.infoPoster.visible = hasImage
    m.infoLabel.visible = not hasImage
    if hasImage
        m.infoPoster.uri = m.top.image
    else
        m.infoLabel.text = m.top.description
    end if
end sub