sub init()
    m.top.panelSize = "narrow"
    m.top.focusable = false
    m.top.hasNextPanel = false
    m.top.suppressLeftArrow = true
    m.infoLabel = m.top.findNode("infoLabel")
    m.infoPoster = m.top.findNode("infoPoster")
    di = CreateObject("roDeviceInfo")
    ui = di.getUIResolution()
    if ui.name = "HD"
        m.infoPoster.translation = [ 18, 15 ]
    else
        m.infoPoster.translation = [ 20, 75 ]
    end if
end sub

' When an image is provided (e.g. a Settings item), show it as a poster instead of the text label.
sub updateDisplay()
    hasImage = m.top.image <> invalid and m.top.image <> ""
    m.infoLabel.text = m.top.description
    m.infoPoster.visible = hasImage
    if hasImage
        m.infoPoster.uri = m.top.image
    end if
end sub