sub main()
  screen = CreateObject("roSGScreen")
  m.port = CreateObject("roMessagePort")
  screen.setMessagePort(m.port)
  scene = screen.CreateScene("HomeScene")
  screen.show()

  while(true)
    msg = wait(200, m.port)
    msgType = type(msg)
    if msgType = "roSGScreenEvent"
      if msg.isScreenClosed() then return
    end if
    if scene.exitApp
      screen.close()
      return
    end if
  end while
end sub
